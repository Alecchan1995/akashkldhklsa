using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FMSS.Models
{
    public class SetDatamodel
    {
        public int Id { get; set; }
        public string Author {get;set; }
        public string FileName { get; set; }
        public string FileLength { get; set; }
        public string FileByte {get;set; }
        public int Level {get;set; }
        public string Department {get;set;}
        public bool Share {get;set;}
        public SetDatamodel(int _Id,string _Author,string _FileName,string _FileLength,
            string _FileByte,int _Level,string _Department, bool _Share){
                Id = _Id;
                Author = _Author;
                FileName = _FileName;
                FileLength = _FileLength;
                FileByte = _FileByte;
                Level = _Level;
                Department = _Department;
                Share = _Share;
            }
    }
}