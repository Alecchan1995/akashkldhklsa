using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FMSS;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using System.IO;
using FMSS.Models;
namespace FMSS.Controllers
{
    public class UploadfileController : Controller
    {
        private readonly ILogger<UploadfileController> _logger;
        public readonly DataContext db;
        private readonly IOptions<ApplicationConfiguration> _optionsApplicationConfiguration;
        public UploadfileController(ILogger<UploadfileController> logger, IOptions<ApplicationConfiguration>  o,DataContext db)
        {
            _logger = logger;
            _optionsApplicationConfiguration = o;
            this.db = db ;
        }

        public IActionResult Uploadfile()
        {
            return View();
        }
        public IActionResult Upload(IFormFile file,string author,string Dep,bool share)
        {
            bool check = false;
           // foreach(string Fileitem in Request.Files){}'
           Console.Write("-------------"+file+"\n");
           if (file.Length > 0 ){
                var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.ToString().Trim('"');
        //    Console.Write("1"+file.ContentDisposition+"\n");
            Console.Write("2"+file.FileName+"\n");
            Console.Write("3"+file.ContentType+"\n");
            Console.Write("4"+file.Length+"\n");
        //    Console.Write("3"+ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.ToString().Trim('"')+"\n");
        //    Console.Write("3"+ContentDispositionHeaderValue.Parse(file.ContentDisposition)+"\n");
        //    Console.Write(_optionsApplicationConfiguration.Value.ServerUploadFolder+"\n");
        //    Console.Write(_optionsApplicationConfiguration.Value.ServerUploadFolder.GetType());
               // using(var stream = System.IO.File.Create(_optionsApplicationConfiguration.Value.ServerUploadFolder+"\\"+fileName)){
               //     file.CopyTo(stream);
               // }
               Console.Write(file.Length.GetType()+"\n");
               var datas = db.FlieData.Select(x=>x).ToList();
               foreach(var item in datas){
                       if(item.FileName == author+"_"+file.FileName){
                            check = true;
                       }
               }
               if (!check){
                var dbd = new Datamodel{ 
                    Author = author,
                    FileName = author+"_"+file.FileName,
                    FileLength = file.Length.ToString(), 
                    FileByte = "1000",
                    Level = 0, 
                    Department = Dep,
                    Share = share 
                    };
                    db.FlieData.Add(dbd);
                    db.SaveChanges();
                    using(var stream = System.IO.File.Create(_optionsApplicationConfiguration.Value.ServerUploadFolder+"\\"+author+"_"+fileName)){
                         file.CopyTo(stream);
                    }
                    Console.Write("Finsih");
               }else{ //check
                    Console.Write("Have a File");
               }
           }else{//check have file
               Console.Write("Null");
           }
           return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}