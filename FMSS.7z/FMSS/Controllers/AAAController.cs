using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
namespace FMSS.Controllers
{
    [Route("api/[controller]/[action]")]
    public class AAAController : Controller
    {
        private readonly ILogger<AAAController> _logger;

        public AAAController(ILogger<AAAController> logger)
        {
            _logger = logger;
        }
        public IActionResult AA()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}