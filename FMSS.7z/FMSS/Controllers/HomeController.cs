﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FMSS.Models;
using System.Web;
namespace FMSS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public readonly DataContext db;
        public HomeController(ILogger<HomeController> logger , DataContext db)
        {
            _logger = logger;
            this.db = db;
        }
        public IActionResult Index()
        {   
            string[] Departmenet = new string[] {"computer"};
            ViewBag.Dep = Departmenet;
            Console.Write(ViewBag.Dep);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Data()
        {
            return View();
        }
    
        public IActionResult DelData(){
            ViewData["data"] = db.FlieData.Select(x=>x).ToList();   
            var datas = db.FlieData.Select(x=>x).ToList();
            Console.WriteLine(datas[0].Id);
            foreach(var data in datas){
          //      db.FlieData.Remove(data);
            }
        //    Console.ReadLine();
        //    db.FlieData.Remove(datas);
        //    db.SaveChanges();
        //    int[] datas = {1,2,3,4,5};
        
        //    ViewBag.datalist = datas;
            int[] nums = {1,2,3,4,5};
            ViewBag.datalist = nums;
            foreach (var num in nums){
                Console.WriteLine(num);
            }
            return View();
        }
        public IActionResult Showdata(){
            var datas = db.FlieData.Select(x=>x).ToList();
            List<SetDatamodel> datalist = new List<SetDatamodel>();
            for (var i =0 ; i < datas.Count;i++){
                var data =new SetDatamodel(
                    datas[i].Id,
                    datas[i].Author,
                    datas[i].FileName,
                    datas[i].FileLength,
                    datas[i].FileByte,
                    datas[i].Level,
                    datas[i].Department,
                    datas[i].Share
                );
                datalist.Add(data);
            }
            ViewBag.datal = datalist; 
            var streamdata = db.Stream.Select(x=>x).ToList();
            Console.WriteLine(streamdata);
            
            foreach(var item in streamdata){
                Console.Write(item);
               // Console.WriteLine(item.Length);   // Byte[]
               // for(var i =0 ; i < item.Length ; i++){
               //     Console.Write(item[i]+" ");
               // }
            }
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
