using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FMSS
{
    public class ApplicationConfiguration
    {
        public string ServerUploadFolder { get; set; }
    }
}