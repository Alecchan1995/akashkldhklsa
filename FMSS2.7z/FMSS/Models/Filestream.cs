using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace FMSS.Models
{
    [Table("FMSUploads")]
    public class Filestream
    {
      [Column("stream_id")]
      [Key]
      [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
      [Required]
      public Guid stream_id{get;set;}
      public Byte[] file_stream{get;set;}
      public string name {get;set;}
      public Byte[] path_locator{get;set;}
      public string parent_path_locator{get;set;}
      public string file_type{get;set;}
      public long cached_file_size{get;set;}
      public DateTimeOffset creation_time{get;set;}
      public DateTimeOffset last_write_time{get;set;}
      public DateTimeOffset last_access_time{get;set;}
      public bool is_directory{get;set;}
      public bool is_offline{get;set;}
      public bool is_hidden{get;set;}
      public bool is_readonly{get;set;}
      public bool is_archive{get;set;}
      public bool is_system{get;set;}
      public bool is_temporary{get;set;}
    }
}