using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace FMSS.Models
{
    public class Comtable
    {
        public int Id { get; set; }
        public string Author {get;set; }
        public string FileName { get; set; }
        public string FileLength { get; set; }
        public string FileByte {get;set; }
        public int Level {get;set; }
        public string Department {get;set;}
        public bool Share {get;set;}
        public Guid stream_id{get;set;}
        public Byte[] file_stream{get;set;}
        public string name {get;set;}
       // public Byte[] path_locator{get;set;}
        public string parent_path_locator{get;set;}
        public string file_type{get;set;}
        public long cached_file_size{get;set;}
        public DateTimeOffset creation_time{get;set;}
        public DateTimeOffset last_write_time{get;set;}
        public DateTimeOffset last_access_time{get;set;}
        public bool is_directory{get;set;}
        public bool is_offline{get;set;}
        public bool is_hidden{get;set;}
        public bool is_readonly{get;set;}
        public bool is_archive{get;set;}
        public bool is_system{get;set;}
        public bool is_temporary{get;set;}
        public Comtable(int _Id,string _Author,string _FileName,string _FileLength,
            string _FileByte,int _Level,string _Department, bool _Share,
            Guid _stream_id, Byte[] _file_stream, string _name, 
            string _parent_path_locator, string _file_type, long _cached_file_size,
            DateTimeOffset _creation_time, DateTimeOffset _last_write_time, 
            DateTimeOffset _last_access_time, bool _is_directory, bool _is_offline,
            bool _is_hidden, bool _is_readonly, bool _is_archive, bool _is_system, 
            bool _is_temporary){
                Id = _Id;
                Author = _Author;
                FileName = _FileName;
                FileLength = _FileLength;
                FileByte = _FileByte;
                Level = _Level;
                Department = _Department;
                Share = _Share;
                stream_id = _stream_id;
                file_stream = _file_stream;
                name = _name;
               // path_locator = _path_locator;
                parent_path_locator = _parent_path_locator;
                file_type = _file_type;
                cached_file_size = _cached_file_size;
                creation_time = _creation_time;
                last_write_time = _last_write_time;
                last_access_time = _last_access_time;
                is_directory = _is_directory;
                is_offline = _is_offline;
                is_hidden = _is_hidden;
                is_readonly = _is_readonly;
                is_archive = _is_archive;
                is_system = _is_system;
                is_temporary = _is_temporary;
            }
    }
}