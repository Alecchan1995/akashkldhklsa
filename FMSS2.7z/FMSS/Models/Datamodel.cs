using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace FMSS.Models
{   
    public class Datamodel
    {
        public int Id { get; set; }
        public string Author {get;set; }
        public string FileName { get; set; }
        public string FileLength { get; set; }
        public string FileByte {get;set; }
        public int Level {get;set; }
        public string Department {get;set;}
        public bool Share {get;set;}
    }
}