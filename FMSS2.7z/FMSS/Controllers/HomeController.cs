﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FMSS.Models;
using System.Web;
namespace FMSS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public readonly DataContext db;
        public HomeController(ILogger<HomeController> logger , DataContext db)
        {
            _logger = logger;
            this.db = db;
        }
        public IActionResult Index()
        {   
            string[] Departmenet = new string[] {"computer"};
            ViewBag.Dep = Departmenet;
            Console.Write(ViewBag.Dep);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Data()
        {
            return View();
        }
    
        public IActionResult DelData(){
            ViewData["data"] = db.FlieData.Select(x=>x).ToList();   
            var datas = db.FlieData.Select(x=>x).ToList();
            Console.WriteLine(datas[0].Id);
            foreach(var data in datas){
          //      db.FlieData.Remove(data);
            }
        //    Console.ReadLine();
        //    db.FlieData.Remove(datas);
        //    db.SaveChanges();
        //    int[] datas = {1,2,3,4,5};
        
        //    ViewBag.datalist = datas;
            
            return View();
        }
        public IActionResult Showdata(){
            var datas = db.FlieData.Select(x=>x).ToList();
            var guids = db.Stream.Select(x=>x.stream_id).ToList();
            var streams = db.Stream.Select(x=>x.file_stream).ToList();
            var names = db.Stream.Select(x=>x.name).ToList();
        //    var locators = db.Stream.Select(x=>x.path_locator).ToList();
            var parent_locators = db.Stream.Select(x=>x.parent_path_locator).ToList();
            var file_types = db.Stream.Select(x=>x.file_type).ToList();
            var cached_file_sizes = db.Stream.Select(x=>x.cached_file_size).ToList();
            var creation_times = db.Stream.Select(x=>x.creation_time).ToList();
            var last_write_times = db.Stream.Select(x=>x.last_write_time).ToList();
            var last_access_times = db.Stream.Select(x=>x.last_access_time).ToList();
            var is_directorys = db.Stream.Select(x=>x.is_directory).ToList();
            var is_offlines = db.Stream.Select(x=>x.is_offline).ToList();
            var is_hiddens = db.Stream.Select(x=>x.is_hidden).ToList();
            var is_readonlys = db.Stream.Select(x=>x.is_readonly).ToList();
            var is_archives = db.Stream.Select(x=>x.is_archive).ToList();
            var is_systems = db.Stream.Select(x=>x.is_system).ToList();
            var is_temporarys = db.Stream.Select(x=>x.is_temporary).ToList();
            List<Comtable> datalist = new List<Comtable>();
            for (var i =0 ; i < datas.Count;i++){
                var data =new Comtable(
                    datas[i].Id,
                    datas[i].Author,
                    datas[i].FileName,
                    datas[i].FileLength,
                    datas[i].FileByte,
                    datas[i].Level,
                    datas[i].Department,
                    datas[i].Share,
                    guids[i],
                    streams[i],
                    names[i],
                  //  locators[i],
                    parent_locators[i],
                    file_types[i],
                    cached_file_sizes[i],
                    creation_times[i],
                    last_write_times[i],
                    last_access_times[i],
                    is_directorys[i],
                    is_offlines[i],
                    is_hiddens[i],
                    is_readonlys[i],
                    is_archives[i],
                    is_systems[i],
                    is_temporarys[i]
                );
                datalist.Add(data);
            }
            ViewBag.datal = datalist;
            foreach(var item in datalist){
                //foreach(var items in item){
                 //   Console.WriteLine(items);
                //}
               // Console.WriteLine(item.Length);   // Byte[]
               // for(var i =0 ; i < item.Length ; i++){
               //     Console.Write(item[i]+" ");
               // }
            }
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
