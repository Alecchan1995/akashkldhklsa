using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FMSS.Models;
namespace FMSS.Controllers
{
    public class ShowdataController : Controller
    {
        private readonly ILogger<ShowdataController> _logger;
        public readonly DataContext db;
        public ShowdataController(ILogger<ShowdataController> logger , DataContext db)
        {
            _logger = logger;
            this.db = db;
        }
        public IActionResult Showdata()
        {
            var dbdata = db.FlieData.Select(x=>x).ToList();
            var dbdetail = db.Stream.Select(x=>x.path_locator).ToList();
            for (var i=0;i<dbdetail.Count; i++){
                Console.Write(dbdetail[i]);
            }
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}