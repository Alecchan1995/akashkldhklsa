﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FMS.Migrations
{
    public partial class MyBaseMigrationtwo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
